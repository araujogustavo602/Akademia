function confirmarAcao() {
    return confirm("Deseja confirmar essa ação?");
}