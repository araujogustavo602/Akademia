<link rel="stylesheet" href="components/components.css">

<header>
    <nav>
        <a href="./index.php">Início</a>
        <a href="modalidae.php">modalidedes</a>
        <a href="#">Planos</a>
        <a href="#">Eventos</a>
        <a href="./areaRestrita.php">Área Restrita</a>
        <a href="./cadastrarUsuario.php">Cadastre-se</a>
     
        

    </nav>

    <img id="logo" src="../assets/logo.png" alt="">
</header>