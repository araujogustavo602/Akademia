<link rel="stylesheet" href="components/components.css">

<footer>
    <strong>Desenvolvido por Gustavo, 2023</strong>
    <strong>Técnico em Informática - Senac Santos</strong>
</footer>
